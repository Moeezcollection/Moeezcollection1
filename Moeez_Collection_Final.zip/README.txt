# Store website
Open `index.html` in a browser.

WhatsApp orders go to: +92 330 5539198
Current product price: Rs 1,300
Delivery: Free

To add 100+ products, add more entries to the `products` array in index.html and place their JPG files in the same folder.
Categories supported: Clothes, Shoes, Jewelry, Bags.
